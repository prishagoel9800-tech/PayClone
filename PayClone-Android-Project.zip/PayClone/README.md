# PayClone — Android payment simulator

PayClone is an independent, clearly labelled **UPI-style payment simulator** for learning and UI prototyping. It is not Google Pay, is not affiliated with Google or NPCI, and does not connect to a bank, UPI switch, payment gateway, or payment account.

## Features
- Native Android app built with Kotlin and Jetpack Compose.
- Camera-based QR scanning using CameraX and Google ML Kit.
- Parses UPI-style `upi://pay` QR payloads to display the payee name and UPI ID.
- Demo amount, note, and local demo PIN flow (`1234`).
- Local transaction history using Room.
- Demo success screen, transaction reference, and confirmation tone.
- GitHub Actions workflow to build a debug APK.

## Safety boundaries
- **No real payments are made.**
- The PIN `1234` is a local demo check only. Never enter a real UPI PIN.
- Success screens and transaction history explicitly say DEMO.
- Do not use screenshots or receipts from this app as proof of payment.
- The app does not verify a recipient or transfer funds.
- Only scan test QR codes you trust. QR data is untrusted input.

## Build the APK using GitHub from an Android phone
1. Download and extract the ZIP.
2. Create a new repository on GitHub named `PayClone`.
3. Upload the extracted project files and folders to the repository root (not the ZIP file itself).
4. Commit the files to the `main` branch.
5. Open the repository on GitHub → **Actions**.
6. Select **Build PayClone Android APK** → **Run workflow**.
7. When the workflow finishes, open the run and download the `PayClone-debug-apk` artifact.
8. Extract the artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from your browser or file manager.

## Local build
Requires JDK 17 and Gradle 8.9:
```bash
gradle assembleDebug
```
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Test QR payload
For a test QR, encode this text as a QR code:
```text
upi://pay?pa=demo.merchant%40payclone&pn=Demo%20Coffee%20Shop
```
The app should read the merchant and open the amount screen. The subsequent payment remains simulated.

## Project structure
```text
PayClone/
  app/
    src/main/
      AndroidManifest.xml
      java/com/payclone/simulator/
        MainActivity.kt
        data/
          Transaction.kt
          TransactionDao.kt
          PayCloneDatabase.kt
  .github/workflows/android.yml
  build.gradle.kts
  settings.gradle.kts
  gradle.properties
```

## Version notes
This starter uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Gradle 8.9, compile SDK 35, and Java 17. The first GitHub Actions run will resolve dependencies from Google's Maven repository and Maven Central.
