package com.payclone.simulator.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val receiverName: String,
    val upiId: String,
    val amount: Double,
    val note: String,
    val transactionRef: String,
    val createdAt: Long = System.currentTimeMillis(),
    val status: String = "DEMO_SUCCESS"
)
