package com.payclone.simulator

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.room.Room
import com.google.mlkit.vision.barcode.Barcode
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.payclone.simulator.data.PayCloneDatabase
import com.payclone.simulator.data.Transaction
import kotlinx.coroutines.launch
import java.net.URLDecoder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

private val Ink = Color(0xFF202124)
private val Blue = Color(0xFF1A73E8)
private val Pale = Color(0xFFF3F6FC)
private val Green = Color(0xFF188038)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Color.White)) { PayCloneApp() } }
    }
}

private data class Payee(val name: String, val upi: String)

@Composable
private fun PayCloneApp() {
    val context = LocalContext.current
    val db = remember { PayCloneDatabase.get(context) }
    val scope = rememberCoroutineScope()
    val transactions by db.transactionDao().observeAll().collectAsState(initial = emptyList())

    var page by remember { mutableStateOf("home") }
    var payee by remember { mutableStateOf(Payee("Demo Store", "demostore@payclone")) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("Demo payment") }
    var pin by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var lastTransaction by remember { mutableStateOf<Transaction?>(null) }

    fun startPayment() {
        val value = amount.toDoubleOrNull()
        if (value == null || value <= 0) { message = "Enter a valid amount"; return }
        if (pin != "1234") { message = "Incorrect demo PIN. Use 1234."; return }
        val tx = Transaction(
            receiverName = payee.name,
            upiId = payee.upi,
            amount = value,
            note = note,
            transactionRef = "PC" + UUID.randomUUID().toString().replace("-", "").take(12).uppercase(Locale.ROOT)
        )
        scope.launch {
            db.transactionDao().insert(tx)
            lastTransaction = tx
            runCatching {
                ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85).startTone(ToneGenerator.TONE_PROP_ACK, 220)
            }
            page = "success"
            pin = ""
            message = ""
        }
    }

    when (page) {
        "home" -> HomeScreen(
            transactions = transactions,
            onScan = { page = "scanner" },
            onPayDemo = { payee = Payee("Demo Merchant", "merchant@payclone"); amount = ""; page = "amount" },
            onHistory = { page = "history" }
        )
        "scanner" -> ScannerScreen(
            onBack = { page = "home" },
            onScanned = { raw ->
                val parsed = parseUpiQr(raw)
                if (parsed != null) {
                    payee = parsed
                    amount = ""
                    page = "amount"
                } else {
                    message = "This QR is not a supported UPI payment QR."
                }
            },
            message = message
        )
        "amount" -> AmountScreen(
            payee = payee,
            amount = amount,
            note = note,
            message = message,
            onAmount = { amount = it; message = "" },
            onNote = { note = it },
            onBack = { page = "home" },
            onContinue = { if (amount.toDoubleOrNull() != null && amount.toDouble() > 0) { message = ""; page = "pin" } else message = "Enter a valid amount" }
        )
        "pin" -> PinScreen(
            amount = amount,
            payee = payee,
            pin = pin,
            message = message,
            onPin = { pin = it.take(4); message = "" },
            onBack = { page = "amount" },
            onConfirm = { startPayment() }
        )
        "success" -> SuccessScreen(tx = lastTransaction, onDone = { page = "home"; amount = ""; note = "Demo payment" })
        "history" -> HistoryScreen(transactions = transactions, onBack = { page = "home" })
    }
}

@Composable
private fun HomeScreen(
    transactions: List<Transaction>,
    onScan: () -> Unit,
    onPayDemo: () -> Unit,
    onHistory: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Color.White)) {
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("PayClone", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.AccountCircle, contentDescription = "Profile", tint = Blue, modifier = Modifier.size(34.dp))
        }
        Text("DEMO SIMULATOR • NO REAL MONEY", color = Color(0xFFB3261E), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
        Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = Pale), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Welcome back", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text("Try a safe, simulated UPI-style payment.", color = Color.DarkGray, modifier = Modifier.padding(top = 6.dp))
                Row(Modifier.fillMaxWidth().padding(top = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = onScan, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                        Spacer(Modifier.width(6.dp)); Text("Scan QR")
                    }
                    OutlinedButton(onClick = onPayDemo, modifier = Modifier.weight(1f)) { Text("Demo pay") }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Recent transactions", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onHistory) { Text("See all") }
        }
        if (transactions.isEmpty()) {
            Text("No transactions yet. Scan a test QR or try Demo pay.", color = Color.Gray, modifier = Modifier.padding(20.dp))
        } else {
            LazyColumn {
                items(transactions.take(4)) { tx ->
                    TransactionRow(tx)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Text("PayClone is an independent simulator and is not affiliated with Google or NPCI.", color = Color.Gray, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(12.dp))
    }
}

@Composable
private fun TransactionRow(tx: Transaction) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(Pale), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = Blue)
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(tx.receiverName, fontWeight = FontWeight.SemiBold)
            Text("DEMO • ${tx.upiId}", fontSize = 11.sp, color = Color.Gray)
        }
        Text("₹" + String.format(Locale.US, "%.2f", tx.amount), fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AmountScreen(
    payee: Payee, amount: String, note: String, message: String,
    onAmount: (String) -> Unit, onNote: (String) -> Unit, onBack: () -> Unit, onContinue: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
        Spacer(Modifier.height(22.dp))
        Text("Paying", color = Color.Gray)
        Text(payee.name, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(payee.upi, color = Color.Gray)
        Spacer(Modifier.height(35.dp))
        OutlinedTextField(value = amount, onValueChange = { if (it.matches(Regex("^\\d{0,7}(\\.\\d{0,2})?$"))) onAmount(it) }, label = { Text("Amount (₹)") }, prefix = { Text("₹ ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = note, onValueChange = onNote, label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
        if (message.isNotBlank()) Text(message, color = Color.Red, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.weight(1f))
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) { Text("Continue") }
        Text("SIMULATION ONLY — no bank or UPI network is contacted.", color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
    }
}

@Composable
private fun PinScreen(
    amount: String, payee: Payee, pin: String, message: String,
    onPin: (String) -> Unit, onBack: () -> Unit, onConfirm: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth()) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
        Spacer(Modifier.height(35.dp))
        Text("Confirm demo payment", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("₹$amount to ${payee.name}", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(30.dp))
        OutlinedTextField(value = pin, onValueChange = onPin, label = { Text("Demo PIN") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("Use demo PIN: 1234", color = Blue, modifier = Modifier.padding(top = 10.dp))
        if (message.isNotBlank()) Text(message, color = Color.Red, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.weight(1f))
        Button(onClick = onConfirm, modifier = Modifier.fillMaxWidth()) { Text("Confirm demo payment") }
        Text("This PIN is only a local demo check. Never enter your real UPI PIN.", color = Color(0xFFB3261E), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
private fun SuccessScreen(tx: Transaction?, onDone: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(92.dp).clip(CircleShape).background(Color(0xFFE6F4EA)), contentAlignment = Alignment.Center) {
            Text("✓", color = Green, fontSize = 58.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(22.dp))
        Text("Demo payment successful", fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text("₹" + String.format(Locale.US, "%.2f", tx?.amount ?: 0.0), fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text("to ${tx?.receiverName ?: "Demo recipient"}", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Pale), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                ReceiptLine("Status", "DEMO ONLY")
                ReceiptLine("UPI ID", tx?.upiId ?: "-")
                ReceiptLine("Demo reference", tx?.transactionRef ?: "-")
                ReceiptLine("Note", tx?.note ?: "-")
            }
        }
        Text("No money was transferred. This is not a real payment confirmation.", color = Color(0xFFB3261E), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 18.dp))
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth().padding(top = 26.dp)) { Text("Done") }
    }
}

@Composable
private fun ReceiptLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, color = Color.Gray, modifier = Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun HistoryScreen(transactions: List<Transaction>, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text("Demo history", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        if (transactions.isEmpty()) Text("No demo transactions yet.", color = Color.Gray, modifier = Modifier.padding(20.dp))
        LazyColumn { items(transactions) { TransactionRow(it) } }
    }
}

@Composable
private fun ScannerScreen(onBack: () -> Unit, onScanned: (String) -> Unit, message: String) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var handled by remember { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }

    LaunchedEffect(Unit) { if (!granted) permission.launch(Manifest.permission.CAMERA) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text("Scan UPI-style QR", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        if (granted) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AndroidView(factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        val provider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                        val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                        val scanner = BarcodeScanning.getClient()
                        val executor = Executors.newSingleThreadExecutor()
                        analysis.setAnalyzer(executor) { imageProxy ->
                            val mediaImage = imageProxy.image
                            if (mediaImage != null && !handled) {
                                val input = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                                scanner.process(input)
                                    .addOnSuccessListener { codes ->
                                        val raw = codes.firstOrNull { it.format == Barcode.FORMAT_QR_CODE }?.rawValue
                                        if (!raw.isNullOrBlank() && !handled) {
                                            handled = true
                                            previewView.post { onScanned(raw) }
                                        }
                                    }
                                    .addOnCompleteListener { imageProxy.close() }
                            } else imageProxy.close()
                        }
                        try {
                            provider.unbindAll()
                            provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                        } catch (_: Exception) { }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }, modifier = Modifier.fillMaxSize())
                Text("Place a test UPI QR inside the camera view", color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).padding(20.dp).background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(10.dp)).padding(12.dp))
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Camera permission is needed to scan QR codes.")
                Button(onClick = { permission.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") }
            }
        }
        if (message.isNotBlank()) Text(message, color = Color.Red, modifier = Modifier.padding(12.dp))
        Text("Only QR codes containing a UPI payment link are parsed. Scanning does not send money.", color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
    }
}

private fun parseUpiQr(raw: String): Payee? {
    return try {
        val uri = android.net.Uri.parse(raw)
        if (!uri.scheme.equals("upi", ignoreCase = true) || !uri.host.equals("pay", ignoreCase = true)) return null
        val pa = uri.getQueryParameter("pa")?.takeIf { it.isNotBlank() } ?: return null
        val pn = uri.getQueryParameter("pn")?.takeIf { it.isNotBlank() } ?: pa.substringBefore("@")
        Payee(URLDecoder.decode(pn, "UTF-8"), pa)
    } catch (_: Exception) { null }
}
