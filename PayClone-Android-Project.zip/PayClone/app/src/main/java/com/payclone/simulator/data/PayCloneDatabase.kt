package com.payclone.simulator.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Transaction::class], version = 1, exportSchema = false)
abstract class PayCloneDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao

    companion object {
        @Volatile private var INSTANCE: PayCloneDatabase? = null
        fun get(context: Context): PayCloneDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    PayCloneDatabase::class.java,
                    "payclone_demo.db"
                ).build().also { INSTANCE = it }
            }
    }
}
